import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import javax.swing.*;
import java.util.concurrent.TimeUnit;


public class test {


    @Test//验证邮箱是否已存在
    public void checkEmailmsg1() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver","E:\\Develop\\IntelliJ\\java_selenium\\src\\main\\resources\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.finexbox.com/Reg/register.html");

        driver.findElement(By.id("email")).sendKeys("379506993@qq.com");
        driver.findElement(By.id("pwd")).sendKeys("123");
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        String emailmsg1 = driver.findElement(By.xpath("//*[@id=\"emailmsg\"]/font")).getText();
        AssertJUnit.assertEquals("Email already exists",emailmsg1);



        driver.findElement(By.id("pwd")).sendKeys("123");
        driver.findElement(By.id("repwd")).sendKeys("1234");
        driver.findElement(By.name("pid")).sendKeys("379506993@qq.com");

        driver.findElement(By.xpath("//*[@id=\"step1\"]/div/p[9]/span/a/span")).click();

    }

    //@Test//验证邮箱格式是否正确
    public void checkEmailmsg2(){
        System.setProperty("webdriver.chrome.driver","E:\\Develop\\IntelliJ\\webdrive\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.finexbox.com");

        driver.findElement(By.xpath("//*[@id=\"footer\"]/div/div[4]/ul/li[4]/a/span")).click();
        driver.findElement(By.xpath("//*[@id=\"topIcon\"]/div/div[3]/a[1]/span")).click();
//        driver.findElement(By.id("email")).clear();
//        driver.findElement(By.id("email")).sendKeys("dsfsdfasd");
//        driver.findElement(By.id("pwd")).clear();
//        driver.findElement(By.id("pwd")).sendKeys("123");
//        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
//        String emailmsg2 = driver.findElement(By.xpath("//*[@id=\"emailmsg\"]/font")).getText();
//        AssertJUnit.assertEquals("Mailbox format not correct",emailmsg2);


        String position=driver.findElement(By.xpath("//*[@id=\"mpanel4\"]/div[2]/div/div/div")).getCssValue("background-position-x");
        int X=Integer.valueOf(position.substring(1,position.length()-2));
        System.out.println(X);
        Actions action=new Actions(driver);
        WebElement Source= driver.findElement(By.xpath("//*[@id=\"mpanel4\"]/div[2]/div/div"));

        action.clickAndHold(Source).moveByOffset(X,0);
        action.release(Source);

        Action actions = action.build();
        actions.perform();



    }

    public void checkpwdmsg(){


    }

    public void checkrepwdmsg(){

    }




}
